<!-- Menghubungkan dengan view template master -->

 
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Ruang'); ?>
 
 
<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
    <div class="mb-3">
        <a href="<?php echo e(route('form-ruang-create')); ?>" class="btn btn-primary">Tambah Ruang</a>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>Nomor</th>
                <th scope="col">Nama Ruang</th>
                <th scope="col">Kuota</th>
                <th scope="col">Sisa Kuota</th>
                <th scope="col">Aksi</th> <!-- Kolom tambahan untuk tombol edit dan delete -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($index + 1); ?></th>
                <td><?php echo e($r['nama_ruang']); ?></td>
                <td><?php echo e($r['kuota']); ?></td>
                <td><?php echo e($r['sisa_kuota']); ?></td>
                <td>
                    <div class="d-flex">
                        <a href="<?php echo e(route('form-edit-ruang', ['id' => $r['id']])); ?>" class="btn btn-primary mr-2">Edit</a>
                        <form action="<?php echo e(route('delete-ruang', ['id' => $r['id']])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppkedua\htdocs\pendaftaran-siswa-baru\resources\views/admin/ruang.blade.php ENDPATH**/ ?>