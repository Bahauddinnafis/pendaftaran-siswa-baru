<!-- Menghubungkan dengan view template master -->

 
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Data Diri'); ?>
 
 
<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<?php $__currentLoopData = $calon_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="card">
        <ol class="list-group list-group-numbered">
            <li class="list-group-item d-flex justify-content-between align-items-start">
              <div class="ms-2 me-auto">
                <div class="fw-bold">Nama Lengkap</div>
                    <?php echo e($siswa['nama_lengkap']); ?>

              </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
              <div class="ms-2 me-auto">
                <div class="fw-bold">Foto</div>
                    <img src="<?php echo e($siswa['foto']); ?>" alt="" width="354px" height="472px">
              </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
              <div class="ms-2 me-auto">
                <div class="fw-bold">Tempat Tanggal Lahir</div>
                <?php echo e($siswa['tempat_lahir']); ?>, <?php echo e($siswa['tanggal_lahir']); ?>

              </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Umur</div>
                  <?php echo e($siswa['umur']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Alamat</div>
                  <?php echo e($siswa['alamat']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Jenis Kelamin</div>
                  <?php echo e($siswa['jenis_kelamin']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Anak ke-</div>
                  <?php echo e($siswa['anak_ke']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Jumlah Saudara</div>
                  <?php echo e($siswa['jumlah_saudara']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Asal Sekolah</div>
                  <?php echo e($siswa['asal_sekolah']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Pilihan Jurusan 1</div>
                  <?php echo e($siswa['id_jurusan1']); ?>

                </div>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-start">
                <div class="ms-2 me-auto">
                  <div class="fw-bold">Pilihan Jurusan 2</div>
                  <?php echo e($siswa['id_jurusan2']); ?>

                </div>
            </li>
          </ol>
    </div>
    <a href="<?php echo e(route('form-edit-data-diri', $siswa['id'])); ?>">
    <button class="w-100 btn btn-lg btn-danger mt-3">Edit Data Diri</button>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppkedua\htdocs\pendaftaran-siswa-baru\resources\views/user/dataDiri.blade.php ENDPATH**/ ?>