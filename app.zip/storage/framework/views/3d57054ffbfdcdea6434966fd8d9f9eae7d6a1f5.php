<!-- Menghubungkan dengan view template master -->

 
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Data Diri Calon Siswa'); ?>
 
 
<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
    <table class="table table-bordered border-primary">
        <thead>
            <tr>
                <th scope="col">Nama Lengkap</th>
                <th scope="col">Foto</th>
                <th scope="col">Tanggal Lahir</th>
                <th scope="col">Tempat Lahir</th>
                <th scope="col">Umur</th>
                <th scope="col">Alamat</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">Anak Ke</th>
                <th scope="col">Jumlah Saudara</th>
                <th scope="col">Asal Sekolah</th>
                <th scope="col">Jurusan 1</th>
                <th scope="col">Jurusan 2</th>
            </tr>
        </thead>
        <tbody>
          
            <?php $__currentLoopData = $calon_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo e($siswa['nama_lengkap']); ?></td>
                <td><img src="<?php echo e($siswa['foto']); ?>" alt="Foto Siswa" width="354px" height="472px"></td>
                <td><?php echo e($siswa['tanggal_lahir']); ?></td>
                <td><?php echo e($siswa['tempat_lahir']); ?></td>
                <td><?php echo e($siswa['umur']); ?></td>
                <td><?php echo e($siswa['alamat']); ?></td>
                <td><?php echo e($siswa['jenis_kelamin']); ?></td>
                <td><?php echo e($siswa['anak_ke']); ?></td>
                <td><?php echo e($siswa['jumlah_saudara']); ?></td>
                <td><?php echo e($siswa['asal_sekolah']); ?></td>
                <td><?php echo e($siswa['id_jurusan1']); ?></td>
                <td><?php echo e($siswa['id_jurusan2']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppkedua\htdocs\pendaftaran-siswa-baru\resources\views/admin/data-calon-siswa.blade.php ENDPATH**/ ?>