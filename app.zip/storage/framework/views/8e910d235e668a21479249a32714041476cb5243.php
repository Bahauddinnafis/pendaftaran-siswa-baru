<!-- Menghubungkan dengan view template master -->

 
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Jadwal'); ?>
 
 
<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

	<div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('create-jadwal')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="tanggaltes" class="form-label">Tanggal Tes</label>
                    <input type="date" class="form-control" name="tanggal_tes" id="tanggal_tes">
                </div>
                <div class="mb-3">
                    <label for="waktutes" class="form-label">Waktu Tes</label>
                    <input type="number" class="form-control" name="waktu_tes" id="waktu_tes">
                  </div>
                <div class="mb-3">
                    <label for="kuota" class="form-label">Kuota</label>
                    <input type="number" class="form-control" name="kuota" id="kuota">
                </div>
                <div class="mb-3">
                    <label for="sisakuota" class="form-label">Sisa Kuota</label>
                    <input type="number" class="form-control" name="sisa_kuota" id="sisa_kuota">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppkedua\htdocs\pendaftaran-siswa-baru\resources\views/admin/form-jadwal.blade.php ENDPATH**/ ?>