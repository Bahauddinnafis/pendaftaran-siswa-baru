<!-- Menghubungkan dengan view template master -->

 
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard'); ?>

<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<?php if(!$response['status_akun']): ?>
<div class="card">
	<div class="card-body">
		<?php if(!$response['data_diri']): ?>
		<div class="alert alert-danger" role="alert">
			Silahkan Isi Data Diri !
		</div>
		<?php endif; ?>

		<?php if(!$response['data_ortu']): ?>
		<div class="alert alert-danger" role="alert">
			Silahkan Isi Data Orang Tua !
		</div>
		<?php endif; ?>

		<?php if(!$response['status_akun']): ?>
		<div class="alert alert-danger" role="alert">
			Anda belum menyimpan permanen akun, silahkan isi data lalu simpan permanen data.
		</div>
		<?php endif; ?>
	</div>
</div>
<?php endif; ?>

<?php if($response['status_akun']): ?>
<div class="card">
  	<div class="card-body">
    	<div class="alert alert-success" role="alert">
			Anda telah menyimpan permanen data. Silahkan unduh kartu dibawah ini.
		</div>
		<a href="/user/export-kartu" target="_blank">
			<button class="w-100 btn btn-lg btn-danger btn-block mt-3">Unduh Kartu</button>
		</a>
	</div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppkedua\htdocs\pendaftaran-siswa-baru\resources\views/user/dashboard.blade.php ENDPATH**/ ?>