<!-- Menghubungkan dengan view template master -->

 
<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Data Diri Orang Tua Wali Siswa'); ?>
 
 
<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<?php $__currentLoopData = $orang_tua_wali_calon_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ortu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ol class="list-group list-group-numbered">
	
	<li class="list-group-item d-flex justify-content-between align-items-start">
	  <div class="ms-2 me-auto">
		<div class="fw-bold">Nama Ayah</div>
		<?php echo e($ortu['nama_ayah']); ?>

	  </div>
	</li>
	<li class="list-group-item d-flex justify-content-between align-items-start">
	  <div class="ms-2 me-auto">
		<div class="fw-bold">Tanggal Lahir Ayah</div>
		<?php echo e($ortu['tanggal_lahir_ayah']); ?>

	  </div>
	</li>
	<li class="list-group-item d-flex justify-content-between align-items-start">
	  <div class="ms-2 me-auto">
		<div class="fw-bold">Tempat Lahir Ayah</div>
		<?php echo e($ortu['tempat_lahir_ayah']); ?>

	  </div>
	</li>
	<li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Pendidikan Ayah</div>
		  <?php echo e($ortu['pendidikan_ayah']); ?>

		</div>
	</li>
	<li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Pekerjaan Ayah</div>
		  <?php echo e($ortu['pekerjaan_ayah']); ?>

		</div>
	</li>
	<li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Penghasilan Ayah</div>
		  <?php echo e($ortu['penghasilan_ayah']); ?>

		</div>
	</li>
	<li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">No Telp Ayah</div>
		  <?php echo e($ortu['no_telp_ayah']); ?>

		</div>
	</li>

	
	<li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Nama Ibu</div>
		  <?php echo e($ortu['nama_ibu']); ?>

		</div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Tanggal Lahir Ibu</div>
		  <?php echo e($ortu['tanggal_lahir_ibu']); ?>

		</div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Tempat Lahir Ibu</div>
		  <?php echo e($ortu['tempat_lahir_ibu']); ?>

		</div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		  <div class="ms-2 me-auto">
			<div class="fw-bold">Pendidikan Ibu</div>
			<?php echo e($ortu['pendidikan_ibu']); ?>

		  </div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Pekerjaan Ayah</div>
		  <?php echo e($ortu['pekerjaan_ibu']); ?>

		</div>
	</li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		  <div class="ms-2 me-auto">
			<div class="fw-bold">Penghasilan Ibu</div>
			<?php echo e($ortu['penghasilan_ibu']); ?>

		  </div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		  <div class="ms-2 me-auto">
			<div class="fw-bold">No Telp Ibu</div>
			<?php echo e($ortu['no_telp_ibu']); ?>

		  </div>
	  </li>

	  
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Nama Wali</div>
		  <?php echo e($ortu['nama_wali']); ?>

		</div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Tanggal Lahir Wali</div>
		  <?php echo e($ortu['tanggal_lahir_wali']); ?>

		</div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Tempat Lahir Wali</div>
		  <?php echo e($ortu['tempat_lahir_wali']); ?>

		</div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		  <div class="ms-2 me-auto">
			<div class="fw-bold">Pendidikan Wali</div>
			<?php echo e($ortu['pendidikan_wali']); ?>

		  </div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		<div class="ms-2 me-auto">
		  <div class="fw-bold">Pekerjaan Ayah</div>
		  <?php echo e($ortu['pekerjaan_wali']); ?>

		</div>
	</li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		  <div class="ms-2 me-auto">
			<div class="fw-bold">Penghasilan Wali</div>
			<?php echo e($ortu['penghasilan_wali']); ?>

		  </div>
	  </li>
	  <li class="list-group-item d-flex justify-content-between align-items-start">
		  <div class="ms-2 me-auto">
			<div class="fw-bold">No Telp Wali</div>
			<?php echo e($ortu['no_telp_wali']); ?>

		  </div>
	  </li>
	<div class="mb-3">
		<a href="<?php echo e(route('orangtua-form-edit', $ortu['id'])); ?>">
			<button class="w-100 btn btn-lg btn-danger mt-3" type="submit">Edit</button>
		</a>
		
	</div>
  </ol>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

   <!-- Bootstrap core JavaScript-->
   <script src="<?php echo asset('assets/vendor/jquery/jquery.min.js'); ?>"></script>
   <script src="<?php echo asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

   <!-- Core plugin JavaScript-->
   <script src="<?php echo asset('assets/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>

   <!-- Custom scripts for all pages-->
   <script src="<?php echo asset('assets/js/sb-admin-2.min.js'); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppkedua\htdocs\pendaftaran-siswa-baru\resources\views/user/orangtua.blade.php ENDPATH**/ ?>